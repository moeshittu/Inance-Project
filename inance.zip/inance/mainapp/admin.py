from django.contrib import admin
from .models import ContactForm,JobApplication
# Register your models here.



class ContactFormAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone', 'email')
admin.site.register(ContactForm, ContactFormAdmin)


class JobApplicationAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'email', 'profile_picture')
admin.site.register(JobApplication, JobApplicationAdmin)
