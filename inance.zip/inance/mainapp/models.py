from django.db import models

class ContactForm(models.Model):
    name = models.CharField(max_length=255)
    phone = models.CharField(max_length=255)
    email = models.EmailField(unique=False)
    message = models.CharField(max_length=255)

from django.db import models

class JobApplication(models.Model):
    full_name = models.CharField(max_length=200)
    email = models.EmailField()
    resume = models.FileField(upload_to='resumes/')
    profile_picture = models.ImageField(upload_to='profile_pics/', blank=True, null=True)
    cover_letter = models.TextField()
    applied_on = models.DateTimeField(auto_now_add=True)

from django.db import models
from django.contrib.auth.models import User
