from django.shortcuts import render,redirect

def home(request):
    return render(request, 'index.html')

def services(request):
    return render(request, 'services.html')


def signin(request):
    return render(request, 'signin.html')

from .models import ContactForm
def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        message = request.POST.get('message')

        ContactForm.objects.create(name = name,
                                   email = email,
                                   phone = phone,
                                    message = message
                                    )
        return redirect('home')
    return render(request, 'contact.html')

from django.shortcuts import render, redirect
from .models import JobApplication

def career(request):
    if request.method == 'POST':
        full_name = request.POST.get('full_name')
        email = request.POST.get('email')
        cover_letter = request.POST.get('cover_letter')
        resume = request.FILES.get('resume')
        profile_picture = request.FILES.get('profile_picture')

        JobApplication.objects.create(
            full_name 	= full_name,	
            email = email,
            cover_letter = cover_letter,
            resume	= resume,		
            profile_picture=profile_picture
        )
        return redirect('home') 
    job = JobApplication.objects.all()
    
    return render(request, 'career.html',{'job':job})

from django.contrib.auth.models import User
from django.contrib.auth import login
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.shortcuts import redirect, render

# def signup(request):
#     if request.method == "POST":
#         username = request.POST['username']
#         email = request.POST['email']
#         password1 = request.POST['password1']
#         password2 = request.POST['password2']

#         if password1 != password2:
#             return redirect('signup')

#         if User.objects.filter(username=username).exists():
#             return redirect('signup')

#         if User.objects.filter(email=email).exists():
#             return redirect('signup')

#         user = User.objects.create_user(username=username, email=email, password=password1)
#         user.save()
#         login(request, user)
#         return redirect('home')

#     return render(request, 'signup.html')


from django.http import JsonResponse

def signup(request):
    if request.method == "POST" and request.headers.get('x-requested-with') == 'XMLHttpRequest':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        if password1 != password2:
            return JsonResponse({'status': 'error', 'message': "Passwords do not match!"})
        if User.objects.filter(username=username).exists():
            return JsonResponse({'status': 'error', 'message': "Username already exists!"})
        if User.objects.filter(email=email).exists():
            return JsonResponse({'status': 'error', 'message': "Email already exists!"})

        user = User.objects.create_user(username=username, email=email, password=password1)
        login(request, user)
        return JsonResponse({'status': 'success', 'message': f"Welcome {username}!"})

    return render(request, 'signup.html')



# from django.contrib.auth import authenticate, login, logout
# def signin(request):
#     if request.method == "POST":
#         username = request.POST['username']
#         password = request.POST['password']
#         user = authenticate(request, username=username, password=password)

#         if user is not None:
#             login(request, user)
#             return redirect('home')
#         else:
#             return redirect('signin')

#     return render(request, 'signin.html')



from django.contrib.auth import authenticate, login, logout
def signin(request):
    if request.method == "POST" and request.headers.get('x-requested-with') == 'XMLHttpRequest':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return JsonResponse({'status': 'success', 'message': "Login Successful!"})
        else:
            return JsonResponse({'status': 'error', 'message': "Invalid username or password!"})

    return render(request, 'signin.html')












def signout(request):
    logout(request)
    return redirect('signin')

from django.contrib.auth.decorators import login_required
from django.shortcuts import render

@login_required
def profile(request):
    return render(request, 'profile.html')

@login_required
def editprofile(request):
    if request.method == "POST":
        user = request.user
        user.first_name = request.POST['first_name']
        user.last_name = request.POST['last_name']
        user.email = request.POST['email']
        user.save()
        return redirect('profile')
    return render(request, 'editprofile.html')